package com.Sapient.collections;

public class Fruits implements Comparable<Fruits> {
	
	String name;
	String color;
	Object a;
	public Fruits(String name, String color) {
		super();
		this.name = name;
		this.color = color;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		System.out.println("Name = "+ name);
		System.out.println("Color = "+ color);
		return result;
	}
	/*@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fruits other = (Fruits) obj;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public int compareTo(Fruits f) {
		if(name.equals(f.getName()))
		{
			return color.compareTo(f.getColor());
		}
		else
		{
			return name.compareTo(f.getName());
		}
		
	}
	
}
