package com.Sapient.collections;

import java.util.Comparator;

public class FruitsComparator implements Comparator<Fruits> {

	@Override
	public  int compare(Fruits obj1, Fruits obj2) {
		
		return obj1.getName().compareTo(obj2.getName());
	}

}
