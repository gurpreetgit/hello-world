package com.Sapient.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMap1 {
	
	public static void main(String[] args) {
		
		Map<Integer,String> aMap = new HashMap<Integer,String>();
		aMap.put(1, "Ashish");
		aMap.put(2, "Amit");
		aMap.put(3, "Aman");
		
		System.out.println(aMap);	

		aMap.put(3, "Sachin");
		System.out.println(aMap);	
		
		Set<Entry<Integer,String>> keySet = aMap.entrySet();
		for(Entry<Integer,String> key1 : keySet){
			System.out.println("Key is " + key1.getKey());
			System.out.println("value is " + key1.getValue());
		}
		
		
		
		
	}

}
