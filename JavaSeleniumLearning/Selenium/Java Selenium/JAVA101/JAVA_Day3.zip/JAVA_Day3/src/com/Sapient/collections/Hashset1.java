package com.Sapient.collections;

import java.util.HashSet;
import java.util.Set;

public class Hashset1 {

	public static void main(String[] args) {
		
		Set<Fruits> fruitList = new HashSet<Fruits>();
		
		fruitList.add(new Fruits("Mango","Yellow"));
		fruitList.add(new Fruits("Apple","Red"));
		fruitList.add(new Fruits("Orange","Orange"));
		fruitList.add(new Fruits("Mango","Yellow"));
		
		System.out.println(fruitList.size());
		//System.out.println(fruitList);
		
		Fruits obj1 = new Fruits("Cherry","Red");
		Fruits obj2= obj1;
		Fruits obj3 = obj1;
		fruitList.add(obj1);
		fruitList.add(obj2);
		fruitList.add(obj3);
		
		
		System.out.println(fruitList.size());
		
		
	}
}