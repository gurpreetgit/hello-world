package com.Sapient.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Iterattor1 implements Iterator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
List<Fruits> alist = new ArrayList<Fruits>();
		
		alist.add(new Fruits("Mango","Yellow"));
		alist.add(new Fruits("Apple","Red"));
		alist.add(new Fruits("Orange","Orange"));
		
		
		

	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}

}
