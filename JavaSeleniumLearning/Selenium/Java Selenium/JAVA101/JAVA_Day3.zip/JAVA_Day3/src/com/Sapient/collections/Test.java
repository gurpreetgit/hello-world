package com.Sapient.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<Fruits> alist = new ArrayList<Fruits>();
		
		Fruits obj1 = new Fruits("Grapes","Green");
		alist.add(obj1);
		alist.add(new Fruits("Mango","Yellow"));
		alist.add(new Fruits("Apple","Red"));
		alist.add(new Fruits("Orange","Orange"));
		System.out.println(alist);
		/*Fruits a =alist.get(1);
		System.out.println(a.getName());
		System.out.println(a.getColor());
		*/
		Fruits obj2 = new Fruits("Apple","Red");
		Collections.sort(alist);
		
		//Collections.sort(alist);
		//System.out.println(alist);
		System.out.println(alist.contains(new Fruits("Apple","Red")));
		System.out.println(alist.contains(new Fruits("Litchi","Red")));
		System.out.println(alist.contains(new Fruits("Apple","Green")));
		System.out.println(alist.contains(obj1));
		System.out.println(alist.contains(obj2));
		
		
		
		
		/*System.out.println(alist);
		
*/
	}

}