package com.Sapient.collections;

public class Testing1 {

	public static void main(String[] args) {
		
		
		Fruits obj1 = new Fruits("Apple","Red");
		Fruits obj2 = new Fruits("Mango","Yellow");
		Fruits obj3 = new Fruits("Apple","Golden");
		System.out.println(obj1);
		
		
		/*System.out.println("Using comparable interface");
		System.out.println(obj1.compareTo(obj2));
		System.out.println(obj2.compareTo(obj1));
		System.out.println(obj1.compareTo(obj3));
		
		System.out.println("Using comparator interface");
		FruitsComparator t1 = new FruitsComparator();
		System.out.println(t1.compare(obj1, obj2));
		System.out.println(t1.compare(obj2, obj1));
		System.out.println(t1.compare(obj1, obj3));
		*/	

	}

}
