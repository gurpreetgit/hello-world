package com.Sapient.collections;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSet1 {
	
	public static void main(String[] args) {
		
		
		Set<Fruits> fruitList = new TreeSet<Fruits>();
		
		Fruits obj1 = new Fruits("Mango","Yellow");
		Fruits obj2 = new Fruits("Apple","Red");
		Fruits obj3 = new Fruits("Banana","Yellow");
		Fruits obj4 = new Fruits("Grapes","Green");
				
		fruitList.add(obj1);
		fruitList.add(obj2);
		fruitList.add(obj3);
		fruitList.add(obj4);
		
		
		System.out.println(fruitList);
	}
	

}
