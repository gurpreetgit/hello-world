package com.sapient.exceptions;

public class Ex1 {
    public static void main(String[] args) {

//        The following line of code will result in arithmetic exception '/ by zero' (unchecked exception)
//        System.out.println(2/0);

//        The following line of code will result in null pointer exception (unchecked exception)
//        Object obj = null;
//        System.out.println(obj.toString());

//        The following lines of code will result in interrupted exception (checked exception)
//        Object obj1 = null;
//        obj1.wait();
    }
}
