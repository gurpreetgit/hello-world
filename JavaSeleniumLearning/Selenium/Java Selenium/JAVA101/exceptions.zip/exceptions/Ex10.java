package com.sapient.exceptions;

public class Ex10 {

    //Using throws
    public static double calcPrincipal(double interest, double rate, double time_in_years) throws Exception{
        if (rate == 0.0 || time_in_years == 0){
            throw new Exception("Rate or Time can't be zero");
        }

        return interest * 100 / rate * time_in_years;
    }

    public static void main(String[] args) {
//        Uncomment the next line. It will give compile error
//        This is because calcPrincipal is using throws keyword. So it is mandatory to handle the exception
//        System.out.println(calcPrincipal(2000, 4, 5));

//      The line 21 doesn't show a compile time error as it's surrounded with a try-catch
        try{
            System.out.println(calcPrincipal(2000, 0, 5));
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}