package com.sapient.exceptions;

public class Ex11 {

    public static int calcPrincipal(int interest, int rate, int time_in_years){
       try{
           return interest * 100 / rate * time_in_years;
       }catch (ArithmeticException e){
           throw new RateOrTimeCantBeZeroException(e);
       }
    }

    public static void main(String[] args) {
        try{
            System.out.println(calcPrincipal(2000, 0, 5));
        }catch (RateOrTimeCantBeZeroException e){
            System.out.println(e.getMessage() + " => " + e.getCause());
        }
    }
}