package com.sapient.exceptions;

public class Ex12 {

    public static int calcPrincipal(int interest, int rate, int time_in_years) throws RateOrTimeCantBeZeroCheckedException {
        try{
            return interest * 100 / rate * time_in_years;
        }catch (ArithmeticException e){
            throw new RateOrTimeCantBeZeroCheckedException(e);
        }
    }

    public static void main(String[] args) {
        try{
            System.out.println(calcPrincipal(2000, 0, 5));
        }catch (RateOrTimeCantBeZeroException e){
            System.out.println(e.getMessage() + " => " + e.getCause());
        }catch (RateOrTimeCantBeZeroCheckedException e) {
            System.out.println(e.getMessage() + " => " + e.getCause());
        }
    }
}