package com.sapient.exceptions;

public class Ex2 {
    public static void main(String[] args) {
//        The following lines demonstrate how to handle exception using a catch block
        try{
            System.out.println(2/0);
        }catch (Exception e){
            System.out.println("An exception was caught.");
            System.out.println(e.getMessage());
        }
    }
}
