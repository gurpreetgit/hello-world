package com.sapient.exceptions;

public class Ex3 {
    public static void main(String[] args) {
//        The following lines demonstrate how to handle exception using a multi catch blocks
//        Comment out line 13 to cause Aritmetic exception and see corresponding catch block getting executed
//        Comment out line 12 to cause Null Pointer exception and see corresponding catch block getting executed

        Object obj = null;

        try{
            System.out.println(2/0);
            System.out.println(obj.toString());

        }catch (ArithmeticException e){
            System.out.println("Aritmetic Exception caught: " + e.getMessage());

        }catch (NullPointerException e){
            System.out.println("Null Pointer Exception was caught: " + e.getMessage());

        }catch (Exception e){
            System.out.println("Exception caught: " + e.getMessage());
        }
    }
}
//Comment line 13 AND comment aritmetic exception catch block. Check what happens !

//Try swapping Exception catch block with Aritmetic/NullPointer catch block.
//This will result in compilation error.
//Exception is parent. It's generic exception. So it should be specified after 'specific' exceptions
//In this code, Arithmetic Exception and Null Pointer Exception are specific exceptions