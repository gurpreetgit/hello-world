package com.sapient.exceptions;

public class Ex4 {
    public static void main(String[] args) {
//        The finally block is always executed, whether an exception occurs or not
//        Comment line 9 or 10, to see finally block in action

        try{
            System.out.println(4/2);
//            System.out.println(2/0);

        }catch (ArithmeticException e){
            System.out.println("Aritmetic Exception caught: " + e.getMessage());

        }catch (NullPointerException e){
            System.out.println("Null Pointer Exception was caught: " + e.getMessage());

        }catch (Exception e){
            System.out.println("Exception caught: " + e.getMessage());

        }finally {
            System.out.println("Nothing can stop me from excecuting. Except, perhaps Dumbledore! ");
        }
    }
}
//Comment line 13 AND comment aritmetic exception catch block. Check what happens !

//Try swapping Exception catch block with Aritmetic/NullPointer catch block.
//This will result in compilation error.
//Exception is parent. It's generic exception. So it should be specified after 'specific' exceptions
//In this code, Arithmetic Exception and Null Pointer Exception are specific exceptions