package com.sapient.exceptions;

public class Ex5_peculiar_finally {

    //return statement, passes the control back to the function caller.
    //if return statement executes, NO statement written after return statement will be executed.

    //Well, except perhaps finally block
    //Try running two examples on line 22,24
    public static int divide(int a, int b){
        try{
            return a/b;
        }catch(Exception e){
            System.out.println("Exception occurred: " + e.getMessage());
        }finally{
            System.out.println("I'm the finally block");
        }
        return 0;
    }

    public static void main(String[] args) {
//        System.out.println(divide(4,2));

//        System.out.println(divide(4,0));

    }
}
