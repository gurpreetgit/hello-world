package com.sapient.exceptions;

public class Ex6 {
    public static void main(String[] args) {
//        Sometimes, the programmer needs to throw an exception
//        We can use 'throw' keyword in such cases

        try{
            throw new ArithmeticException("This is an arithmetic exception.");

        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Invalid array index: " + e.getMessage());
        }catch (ArithmeticException e){
            System.out.println("Arithmetic Exception: " + e.getMessage());
        }catch (Exception e){
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }
}
