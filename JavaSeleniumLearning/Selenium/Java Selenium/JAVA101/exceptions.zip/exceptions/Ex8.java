package com.sapient.exceptions;

public class Ex8 {
    //Uncomment line 11, then
    //The code gives compile error. Because Exception thrown within calcPrincipal
    //either needs to be handled within using try-catch blocks within the method
    //or we  need to add throws keyword in method signature.
    //check out upcoming examples
    public static double calcPrincipal(double interest, double rate, double time_in_years){
        if (rate == 0.0 || time_in_years == 0){
//            throw new Exception("Rate or Time can't be zero");
        }

        return interest * 100 / rate * time_in_years;
    }
    public static void main(String[] args) {
        System.out.println(calcPrincipal(2000, 4, 5));

        try{
            System.out.println(calcPrincipal(2000, 0, 5));
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}