package com.sapient.exceptions;

public class Ex9 {

    //Using try-catch block within method
    public static double calcPrincipal(double interest, double rate, double time_in_years){
        try{
            if (rate == 0.0 || time_in_years == 0){
                throw new Exception("Rate or Time can't be zero");
            }
        }catch (Exception e){
            System.out.println(e.getMessage());
            return 0;
        }

        return interest * 100 / rate * time_in_years;
    }

    public static void main(String[] args) {
        System.out.println(calcPrincipal(2000, 4, 5));

        try{
            System.out.println(calcPrincipal(2000, 0, 5));
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}