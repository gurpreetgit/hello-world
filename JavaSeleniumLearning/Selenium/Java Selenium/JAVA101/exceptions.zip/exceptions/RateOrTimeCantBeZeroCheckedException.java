package com.sapient.exceptions;

public class RateOrTimeCantBeZeroCheckedException extends Exception {
    private static String customMsg = "Business Checked Exception: Rate or time can't be zero";

    public RateOrTimeCantBeZeroCheckedException(Throwable cause) {
        this(customMsg, cause);
    }

    private RateOrTimeCantBeZeroCheckedException() {
        super();
    }

    private RateOrTimeCantBeZeroCheckedException(String message) {
        super(message);
    }

    private RateOrTimeCantBeZeroCheckedException(String message, Throwable cause) {
        super(message, cause);
    }

    private RateOrTimeCantBeZeroCheckedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
