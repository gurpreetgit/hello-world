package com.sapient.exceptions;

//To create custom unchecked exception, extend RuntimeException class
public class RateOrTimeCantBeZeroException extends RuntimeException{
    private static String customMsg = "Business Exception: Rate or time can't be zero";

    public RateOrTimeCantBeZeroException(Throwable cause) {
        this(customMsg, cause);
    }

    private RateOrTimeCantBeZeroException() {
        super();
    }

    private RateOrTimeCantBeZeroException(String message) {
        super(message);
    }

    private RateOrTimeCantBeZeroException(String message, Throwable cause) {
        super(message, cause);
    }

    private RateOrTimeCantBeZeroException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
